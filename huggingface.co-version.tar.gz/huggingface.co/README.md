---
title: 全自动助手
emoji: 🤖
colorFrom: blue
colorTo: green
sdk: docker
pinned: false
license: mit
app_port: 7860
---

# 全自动助手 Hugging Face Spaces 版

这是“全自动助手 / Account-Auto-Sign”的 Hugging Face Spaces Docker 版本，前端和后端合并到一个容器中运行。

## 访问方式

Space 启动完成后，直接打开页面即可使用：

- 前端界面：Space 首页
- 健康检查：`/api/health`
- API 文档：`/docs`

## 默认运行方式

Hugging Face Spaces 会自动读取根目录的 `Dockerfile` 并构建镜像。

容器内服务：

- FastAPI 监听端口：`7860`
- Vue 前端静态文件：由 FastAPI 直接托管
- API 路径：`/api/*`
- 数据库：SQLite，默认路径 `/data/data.db`

## 环境变量

可在 Hugging Face Space 的 Settings -> Variables and secrets 中配置：

| 变量 | 默认值 | 说明 |
|------|--------|------|
| `SECRET_KEY` | `your-secret-key-change-in-production` | JWT 签名密钥，建议部署后修改 |
| `DATABASE_URL` | `sqlite:////data/data.db` | SQLite 数据库地址 |
| `PLAYWRIGHT_HEADLESS` | `true` | 浏览器自动化是否使用无头模式 |
| `SMTP_HOST` | 空 | 邮件服务器地址 |
| `SMTP_PORT` | `587` | 邮件服务器端口 |
| `SMTP_USER` | 空 | 邮箱账号 |
| `SMTP_PASSWORD` | 空 | 邮箱授权码 |
| `EMAIL_FROM` | 空 | 发件邮箱 |

## 注意事项

免费版 Hugging Face Spaces 更适合演示和轻量使用。SQLite 数据默认放在容器内路径，Space 重建或重启后可能丢失数据；如果要长期使用，建议后续改成外部数据库。

Playwright 浏览器自动化已经在 Dockerfile 中安装 Chromium，但某些网站可能会限制云端 IP、验证码或自动化浏览器访问。如果签到失败，请优先使用 Cookie、Token 或插件方式。

## 本地测试

```bash
docker build -t quan-zidong-zhushou-hf .
docker run --rm -p 7860:7860 quan-zidong-zhushou-hf
```

访问：

```text
http://localhost:7860
```

## 项目功能

- 用户注册、登录、JWT 鉴权
- 网站管理
- 多账号管理
- Cron 定时任务
- 签到日志
- 邮件通知
- Playwright 自动化签到
- 自定义插件扩展
